declare module 'similarity' {
    export default function similarity (a: string, b: string, opts?: { sensitive: boolean }): number
}
