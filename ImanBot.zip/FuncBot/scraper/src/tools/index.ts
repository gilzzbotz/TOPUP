export { default as didyoumean } from './didyoumean.js'
